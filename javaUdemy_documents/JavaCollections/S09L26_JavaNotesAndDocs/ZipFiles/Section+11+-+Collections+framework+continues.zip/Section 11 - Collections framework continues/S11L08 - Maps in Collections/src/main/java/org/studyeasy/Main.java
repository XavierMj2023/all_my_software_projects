package org.studyeasy;


import java.util.HashMap;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        Map<String ,String> map = new HashMap<>();
        map.put("a1", "Chaand");
        map.put("a2", "Rahul");
        map.put("a5", "John");
        map.put("a0", "Aafiya");
        map.put("a9", "Chaand");


        System.out.println(map);


    }
}



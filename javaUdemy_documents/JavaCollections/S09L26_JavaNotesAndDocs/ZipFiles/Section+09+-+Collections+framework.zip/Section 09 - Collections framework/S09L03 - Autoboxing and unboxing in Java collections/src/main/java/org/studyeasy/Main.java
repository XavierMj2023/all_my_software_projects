package org.studyeasy;
import java.util.ArrayList;

class IntWrapper{
    public int num;
}

public class Main {
    public static void main(String[] args) {
        ArrayList<Integer> numbersList = new ArrayList<>();
        numbersList.add(25);
        numbersList.add(28);
        System.out.println(numbersList);

         
    }
}
package org.studyeasy;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<Double> numbersList = new ArrayList<>();
        numbersList.add(Double.valueOf(25.5)); // autoboxing
        System.out.println(numbersList);
        System.out.println(numbersList.get(0).doubleValue()); // unboxing





         
    }
}
package org.studyeasy;

public class Main {

    public static void main(String[] args) {
        String[] names;
        names = new String[10];
        names[0] = "Chaand";
        names[5] = "studyeasy";
        System.out.println(names[5]);


    }
}
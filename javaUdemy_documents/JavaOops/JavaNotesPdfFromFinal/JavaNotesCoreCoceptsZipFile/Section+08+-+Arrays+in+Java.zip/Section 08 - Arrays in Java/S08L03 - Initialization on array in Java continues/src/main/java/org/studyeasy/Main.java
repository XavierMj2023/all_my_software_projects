package org.studyeasy;

public class Main {

    public static void main(String[] args) {

        float[] values = {10.0f, 25.1252142f, 60};
        System.out.println(values[1]);

    }
}
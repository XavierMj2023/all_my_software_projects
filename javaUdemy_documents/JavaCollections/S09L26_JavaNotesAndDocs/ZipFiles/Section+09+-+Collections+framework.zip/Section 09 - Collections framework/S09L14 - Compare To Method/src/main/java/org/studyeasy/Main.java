package org.studyeasy;

public class Main {
    public static void main(String[] args) {
        Character x = 'a';

        
    }

}